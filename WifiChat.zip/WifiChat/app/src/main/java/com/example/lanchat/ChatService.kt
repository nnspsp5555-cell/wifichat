package com.example.lanchat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/**
 * خدمة تبقي الدردشة شغّالة بالخلفية وتعرض إشعاراً عند وصول رسالة.
 */
class ChatService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.lanchat.STOP"
        private const val CH_SERVICE = "lanchat_service"
        private const val CH_MSG = "lanchat_messages"
        private const val ID_SERVICE = 1
        private const val ID_MSG = 2
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ChatNet.onIncoming = null
            ChatNet.stop()
            stopForeground(true)
            stopSelf()
            return START_NOT_STICKY
        }

        createChannels()
        val ongoing = buildOngoing()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID_SERVICE, ongoing, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ID_SERVICE, ongoing)
        }

        // إذا أندرويد أعاد تشغيل الخدمة بدون التطبيق، نقرأ الاسم المحفوظ
        if (ChatNet.myName.isEmpty()) {
            val saved = getSharedPreferences("lanchat", MODE_PRIVATE).getString("name", "") ?: ""
            ChatNet.myName = saved
        }

        ChatNet.onIncoming = { m -> if (!ChatNet.appVisible) notifyMessage(m) }
        ChatNet.start(applicationContext)
        return START_STICKY
    }

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_SERVICE, "الدردشة شغّالة", NotificationManager.IMPORTANCE_LOW)
        )
        val msg = NotificationChannel(CH_MSG, "الرسائل الجديدة", NotificationManager.IMPORTANCE_HIGH)
        msg.enableVibration(true)
        nm.createNotificationChannel(msg)
    }

    private fun openAppIntent(): PendingIntent {
        val i = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(
            this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    private fun buildOngoing(): Notification {
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ChatService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CH_SERVICE)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle("دردشة الشبكة شغّالة")
            .setContentText("تستقبل الرسائل من الأجهزة على نفس الواي فاي")
            .setOngoing(true)
            .setContentIntent(openAppIntent())
            .addAction(0, "إيقاف", stop)
            .build()
    }

    private fun notifyMessage(m: ChatMessage) {
        val n = NotificationCompat.Builder(this, CH_MSG)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle(m.name)
            .setContentText(m.text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(m.text))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .setContentIntent(openAppIntent())
            .build()
        getSystemService(NotificationManager::class.java).notify(ID_MSG, n)
    }

    override fun onDestroy() {
        ChatNet.onIncoming = null
        super.onDestroy()
    }
}
